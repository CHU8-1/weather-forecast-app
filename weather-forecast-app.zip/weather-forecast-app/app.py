import streamlit as st
import requests
import pandas as pd
import plotly.express as px
from datetime import datetime

st.title("🌤️ 七日天氣預報 - 多城市查詢")
st.write("資料來源：OpenWeather API")

api_key = st.secrets["OPENWEATHER_API_KEY"]
cities = st.text_input("輸入城市（用逗號分隔，例如：Taipei, Tokyo, New York）", "Taipei")

if st.button("查詢天氣"):
    city_list = [c.strip() for c in cities.split(",")]
    for city in city_list:
        url = f"https://api.openweathermap.org/data/2.5/forecast?q={city}&appid={api_key}&units=metric&cnt=56"
        res = requests.get(url)
        if res.status_code != 200:
            st.error(f"{city} 查詢失敗：{res.json().get('message', '未知錯誤')}")
            continue
        data = res.json()
        df = pd.DataFrame(data['list'])
        df['dt'] = pd.to_datetime(df['dt'], unit='s')
        df['temp'] = df['main'].apply(lambda x: x['temp'])
        df['time'] = df['dt'].dt.strftime('%m/%d %H:%M')
        fig = px.line(df, x='time', y='temp', title=f"{city} 未來 7 天氣溫趨勢")
        st.plotly_chart(fig)